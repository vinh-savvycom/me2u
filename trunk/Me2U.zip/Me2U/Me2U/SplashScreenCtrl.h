//
//  SplashScreenCtrl.h
//  Me2U
//
//  Created by duong2179 on 7/11/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HomeScreenCtrl.h"

@interface SplashScreenCtrl : UIViewController

- (void)pushSecondController;

@end
