//
//  Global.m
//  Me2U
//
//  Created by duong2179 on 7/12/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Global.h"

DataAccessProcess *gDataAccess = [[DataAccessProcess alloc] init];
NSMutableArray *arrOfBasket = [[NSMutableArray alloc] init];
