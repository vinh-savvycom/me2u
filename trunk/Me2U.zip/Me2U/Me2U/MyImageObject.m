//
//  MyImageObject.m
//  Me2U
//
//  Created by duong2179 on 7/16/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "MyImageObject.h"

@implementation MyImageObject

@synthesize url, content;

@end
