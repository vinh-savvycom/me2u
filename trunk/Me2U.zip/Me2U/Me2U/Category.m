//
//  Category.m
//  Me2U
//
//  Created by duong2179 on 7/14/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Category.h"


@implementation Category

@dynamic id_category;
@dynamic name;
@dynamic image;
@dynamic total_product;

@end
