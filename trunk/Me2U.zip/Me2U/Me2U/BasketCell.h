//
//  BasketCell.h
//  Me2U
//
//  Created by duong2179 on 7/13/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BasketCell : UITableViewCell

@property (nonatomic, retain) IBOutlet UILabel *lblProductName;
@property (nonatomic, retain) IBOutlet UILabel *lblProductNumber;

@end
