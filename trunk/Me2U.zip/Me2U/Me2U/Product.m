//
//  Product.m
//  Me2U
//
//  Created by duong2179 on 7/14/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Product.h"


@implementation Product

@dynamic id_product;
@dynamic name;
@dynamic id_parent;
@dynamic image;
@dynamic descriptions;
@dynamic quantity;
@dynamic model;
@dynamic price;

@end
