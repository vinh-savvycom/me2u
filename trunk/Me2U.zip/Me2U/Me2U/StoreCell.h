//
//  StoreCell.h
//  Me2U
//
//  Created by duong2179 on 7/12/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface StoreCell : UITableViewCell

@property (nonatomic, retain) IBOutlet UIImageView *imvProductLogo;
@property (nonatomic, retain) IBOutlet UILabel *lblProductName;

@end
