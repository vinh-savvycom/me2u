//
//  MyImageObject.h
//  Me2U
//
//  Created by duong2179 on 7/16/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MyImageObject : NSObject

@property (nonatomic, retain) NSString* url;
@property (nonatomic, retain) UIImage* content;

@end
