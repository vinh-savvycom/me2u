//
//  Filter.m
//  Me2U
//
//  Created by duong2179 on 7/14/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Filter.h"


@implementation Filter

@dynamic id_filter;
@dynamic name;

@end
